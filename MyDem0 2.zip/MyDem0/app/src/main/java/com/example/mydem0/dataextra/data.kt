package com.example.mydem0.dataextra

 class data()
 {

         val vowels = arrayOf("a", "e", "i", "o", "u")


 }